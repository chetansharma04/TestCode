package com.chetan.spring.transactionMgmt.tm1.bo.boImpl;

import org.springframework.stereotype.Service;

import com.chetan.spring.transactionMgmt.tm1.bo.ProductQohBo;
import com.chetan.spring.transactionMgmt.tm1.model.ProductQoh;

@Service
public class ProductQohBoImpl implements ProductQohBo {

	@Override
	public void save(ProductQoh productQoh) {
		// TODO Auto-generated method stub
		
	}

	
}
