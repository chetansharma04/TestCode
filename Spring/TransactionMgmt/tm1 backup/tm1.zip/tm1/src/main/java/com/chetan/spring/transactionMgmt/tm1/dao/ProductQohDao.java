package com.chetan.spring.transactionMgmt.tm1.dao;

import com.chetan.spring.transactionMgmt.tm1.model.ProductQoh;

public interface ProductQohDao {
	
	void save(ProductQoh productQoh);
	
}
