package ucf.restclient;

import java.io.IOException;

import javax.ws.rs.core.MediaType;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import ucf.beans.OAuthCode;

import com.ibm.icu.util.Calendar;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class UCFRestClient {
	
	private static Client client = null;
	private static WebResource webRessource= null;
	private static String client_id = null;
	private static String client_secret = null;
	private static String redirect_uri = null;
	private static OAuthCode oAuthCode = null;
	
	private static void setUCFMasterSettings(){
		client=Client.create();
		webRessource=client.resource("https://auth.unifiedcompliance.com/token");
		client_id = "107cce70-194d-4dfc-a5a0-7219ecf90e7c";
		client_secret = "b2ZzMp5Y4pMv4Tko+bBF7STpbebbpE6u";
		redirect_uri="http://220.227.11.67:8888/TruOps/lmur/login.do";
	}
	public static void main(String arg[])
	{
		setUCFMasterSettings();
		oAuthCode = getOAuthCode();
		
		OAuthCode refreshCode = getRefreshCode(oAuthCode.getAccess_token(), oAuthCode.getRefresh_token());
		
//		String responseEntity=getEntityList(refreshCode);
//		System.out.println("responseEntity = "+responseEntity);
		
		checkTokenExpiry(refreshCode);
	
	}
	
	//Retrieve OAuthCode and initial refresh code based on URL Code
	public static OAuthCode getOAuthCode()
	{
		System.out.println("In getOAuthCode()");
		String oAuthCodeStr=null;
		OAuthCode oAuthCode=null;
		try{
			String urlCode = "5f97e7b242ced7392689a110196cb02ff3671052";
			
			String input = "{\"grant_type\":\"authorization_code\",\"code\":\"" +urlCode+ "\",\"client_id\":\"" +client_id+ "\",\"client_secret\":\"" +client_secret+ "\",\"redirect_uri\":\"" +redirect_uri+ "\"}";
			
			ClientResponse response=webRessource.type(MediaType.APPLICATION_JSON_TYPE)
			.header("Content-Type", "application/json").header("Accept", "application/vnd.ucf.v1+json")
			.post(ClientResponse.class, input);
			
			System.out.println("getOAuthCode response status: "+response.getStatus());
			if(response.getStatus()==200)
			{
				oAuthCodeStr=response.getEntity(String.class);
				oAuthCode=convertJsonToObject(oAuthCodeStr, OAuthCode.class);
				System.out.println("oAuthCode.toString()=="+oAuthCode.toString());
					
			}else{
				System.out.println("oAuthCode not received");
			}
			
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
			return oAuthCode;
	}
	
	
	//Retrieve Refresh based on URL Code
	public static OAuthCode getRefreshCode(String token,String refreshToken)
	{
		System.out.println("In getRefreshCode()");
		String  _oAuth_token="Bearer "+token;
		String input = "{\"grant_type\":\"refresh_token\",\"refresh_token\":\"" +refreshToken+ "\",\"client_id\":\"" +client_id+ "\",\"client_secret\":\"" +client_secret+ "\",\"redirect_uri\":\"" +redirect_uri+ "\"}";
		ClientResponse response=webRessource.type(MediaType.APPLICATION_JSON_TYPE)
		.header("Content-Type", "application/json").header("Accept", "application/vnd.ucf.v1+json").header("Authorization", _oAuth_token)
		.post(ClientResponse.class, input);
		
		System.out.println("getRefreshCode status = "+response.getStatus());
		String refreshCodeString=response.getEntity(String.class);
		
		OAuthCode refreshCode = convertJsonToObject(refreshCodeString, OAuthCode.class);
		System.out.println("refreshCode.toString()=="+refreshCode.toString());
		
		
		return refreshCode;
	}
	
	static void checkTokenExpiry(OAuthCode refreshCode){
		for(int minutesCtr=1;minutesCtr<=60;minutesCtr++){
			
			try {
				System.out.println(minutesCtr+". checkTokenExpiry = "+Calendar.getInstance().getTime());
				getEntityList(refreshCode);
				Thread.sleep(1000*60);
				if(minutesCtr == 50){
					getRefreshCode(oAuthCode.getAccess_token(), oAuthCode.getRefresh_token());
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}
	

	/**
	 * @description used to convert json response String to Object.
	 * @param <T>
	 * @param responseString
	 * @param T
	 * @return
	 */
	public static <T> T convertJsonToObject(String responseString,Class<T> T)
	{
		ObjectMapper mapper=new ObjectMapper();
		T t=null;
		try {
			 t=mapper.readValue(responseString, T);
		} catch (JsonParseException e) {
			
			e.printStackTrace();
		} catch (JsonMappingException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		return t;
	}
	
	
	public static String getEntityList(OAuthCode refreshCode)
	{
		String entityListResponseData=null;
		try{
//			Client client=Client.create();
//			String  _oAuth_token="Bearer 262f0cee5280abb7c0eba2233dbb948ec057f23b";
			webRessource=client.resource("https://api.unifiedcompliance.com/entities");
			ClientResponse entityListResponse=webRessource.type(MediaType.APPLICATION_JSON_TYPE)
			.header("Content-Type", "application/json").header("Accept", "application/vnd.ucf.v1+json").header("Authorization", "Bearer "+refreshCode.getAccess_token())
			.get(ClientResponse.class);
			
			System.out.println(entityListResponse.getStatus());
			entityListResponseData=entityListResponse.getEntity(String.class);
			System.out.println("entityListResponseData == "+entityListResponseData);
			
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
			return entityListResponseData;
			
	}


	public static String getCCHAdListToAuthDocs(OAuthCode refreshCode)
	{
		String entityListResponseData=null;
		try{
//			Client client=Client.create();
//			String  _oAuth_token="Bearer 262f0cee5280abb7c0eba2233dbb948ec057f23b";
			webRessource=client.resource("https://api.unifiedcompliance.com/cch-ad-lists-to-authority-documents/paged");
			ClientResponse entityListResponse=webRessource.type(MediaType.APPLICATION_JSON_TYPE)
			.header("Content-Type", "application/json").header("Accept", "application/vnd.ucf.v1+json").header("Authorization", "Bearer "+refreshCode.getAccess_token())
			.get(ClientResponse.class);
			
			System.out.println(entityListResponse.getStatus());
			entityListResponseData=entityListResponse.getEntity(String.class);
			System.out.println("entityListResponseData == "+entityListResponseData);
			
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
			return entityListResponseData;
			
	}

}
